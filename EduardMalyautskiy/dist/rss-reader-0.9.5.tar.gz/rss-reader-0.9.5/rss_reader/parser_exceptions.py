class NoItemsException(Exception):
    pass


class NotRSSException(Exception):
    pass


class RequestProblem(Exception):
    pass

class IncorrectPath(Exception):
    pass

