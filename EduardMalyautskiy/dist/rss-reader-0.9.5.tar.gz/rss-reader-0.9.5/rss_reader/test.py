from bs4 import BeautifulSoup

a = '<p><a href="https://auto.onliner.by/2022/06/29/nepogoda-8"><img src="https://content.onliner.by/news/thumbnail/ac661c9b4927164b63e8a472ab7e5bb5.jpeg" alt="" /></a></p><p>Сегодня в Могилеве ливень затапливал улицы, а ветер сносил деревья, билборды и ветряки. Множество фотографий с последствиями разбушевавшейся стихии очевидцы выложили в социальных сетях. В МЧС сообщили, что пострадавших нет, но деревья повредили пять легковых автомобилей.</p><p><a href="https://auto.onliner.by/2022/06/29/nepogoda-8">Читать далее…</a></p>'

soup = BeautifulSoup(a, features="html.parser")
print(soup.find('ismg').get('srcd'))